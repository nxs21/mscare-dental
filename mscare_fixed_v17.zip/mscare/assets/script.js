(function () {
  var btn = document.getElementById('navToggle');
  var links = document.getElementById('navLinks');
  if (btn && links) {
    btn.addEventListener('click', function () {
      var open = links.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  // password show / hide
  document.querySelectorAll('[data-toggle-pass]').forEach(function (b) {
    b.addEventListener('click', function () {
      var input = document.getElementById(b.getAttribute('data-toggle-pass'));
      if (!input) return;
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      b.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      b.classList.toggle('on', show);
    });
  });

  // names are stored in capital letters
  document.querySelectorAll('[data-uppercase]').forEach(function (el) {
    el.addEventListener('input', function () {
      var a = el.selectionStart, z = el.selectionEnd, u = el.value.toUpperCase();
      if (u !== el.value) { el.value = u; try { el.setSelectionRange(a, z); } catch (e) {} }
    });
  });

  var search = document.getElementById('svcSearch');
  var grid = document.getElementById('svcGrid');
  if (!search || !grid) return;
  var cards = grid.querySelectorAll('.svc-card');
  var chips = document.querySelectorAll('#svcChips .chip');
  var count = document.getElementById('svcCount');
  var empty = document.getElementById('svcEmpty');
  var cat = '';

  function apply() {
    var q = search.value.trim().toLowerCase();
    var shown = 0;
    cards.forEach(function (card) {
      var match = (!q || card.getAttribute('data-text').indexOf(q) > -1) &&
                  (!cat || card.getAttribute('data-cat') === cat);
      card.hidden = !match;
      if (match) shown++;
    });
    count.textContent = shown + (shown === 1 ? ' service' : ' services');
    empty.hidden = shown !== 0;
  }

  search.addEventListener('input', apply);
  chips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      chips.forEach(function (c) { c.classList.remove('on'); });
      chip.classList.add('on');
      cat = chip.getAttribute('data-cat');
      apply();
    });
  });
})();
