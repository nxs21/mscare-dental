(function () {
  var form = document.getElementById('bookForm');
  if (!form || !window.MSC) return;

  var data = window.MSC;
  var DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  var CHECK = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12l5 5L20 7"/></svg>';

  var panels = form.querySelectorAll('.panel');
  var tabs = form.querySelectorAll('.steps li');
  var dateGrid = document.getElementById('dateGrid');
  var timeGrid = document.getElementById('timeGrid');
  var dateVal = document.getElementById('dateVal');
  var timeVal = document.getElementById('timeVal');
  var altDate = document.getElementById('altDate');
  var formError = document.getElementById('formError');
  var step = 1;
  var last = panels.length;                 // 4 for guests, 3 for signed-in patients (no details step)
  var member = data.member || null;
  var state = { date: '', time: '' };

  function pad(n) { return n < 10 ? '0' + n : String(n); }
  function iso(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function parseISO(s) { var p = s.split('-'); return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2])); }
  function branchKey() {
    var c = form.querySelector('input[name="branch"]:checked');
    return c ? c.value : '';
  }
  function isOpen(key, d) {
    return !!data.branches[key] && data.branches[key].days.indexOf(DAYS[d.getDay()]) > -1;
  }
  function minutes(label) {
    var m = /^(\d+):(\d+) (AM|PM)$/.exec(label);
    var h = Number(m[1]) % 12;
    if (m[3] === 'PM') h += 12;
    return h * 60 + Number(m[2]);
  }
  function slotStatus(dateStr, time) {
    if ((data.taken[dateStr] || []).indexOf(time) > -1) return 'taken';
    if (dateStr === iso(new Date())) {
      var n = new Date();
      if (minutes(time) <= n.getHours() * 60 + n.getMinutes()) return 'past';
    }
    return 'free';
  }

  function setErr(name, msg) {
    var el = form.querySelector('[data-err="' + name + '"]');
    if (!el) return;
    el.textContent = msg || '';
    var holder = el.closest('.field, .group');
    if (holder) holder.classList.toggle('has-error', !!msg);
  }

  function validate(n) {
    var ok = true;
    function need(name, cond, msg) {
      setErr(name, cond ? '' : msg);
      if (!cond) ok = false;
    }
    var f = form.elements;
    if (n === 1) {
      need('branch', !!branchKey(), 'Choose a branch.');
      need('service', !!f.service.value, 'Choose a service.');
    }
    if (n === 2) {
      need('date', !!state.date, 'Choose a date.');
      need('time', !!state.time, 'Choose a time.');
    }
    if (n === 3 && f.first_name) {
      need('first_name', f.first_name.value.trim().length >= 2, 'Enter your first name.');
      need('last_name', f.last_name.value.trim().length >= 2, 'Enter your last name.');
      need('phone', /^(\+63|63|0)?9\d{9}$/.test(f.phone.value.replace(/[\s\-()]/g, '')), 'Enter a valid mobile number.');
      need('email', /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.value.trim()), 'Enter a valid email address.');
      need('current_patient', !!form.querySelector('input[name="current_patient"]:checked'), 'Choose Yes or No.');
    }
    return ok;
  }

  function show(n, quiet) {
    step = n;
    panels.forEach(function (p) { p.hidden = Number(p.getAttribute('data-panel')) !== n; });
    tabs.forEach(function (t) {
      var k = Number(t.getAttribute('data-step'));
      t.classList.toggle('active', k === n);
      t.classList.toggle('done', k < n);
      t.querySelector('.num').innerHTML = k < n ? CHECK : String(k);
      t.querySelector('button').disabled = k >= n;
    });
    if (n === 2) { renderDates(); renderTimes(); }
    if (n === last) renderReview();
    if (!quiet) form.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function renderDates() {
    var key = branchKey();
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    dateGrid.innerHTML = '';
    for (var i = 0; i < 14; i++) {
      var d = new Date(today);
      d.setDate(today.getDate() + i);
      var s = iso(d);
      var open = isOpen(key, d);
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'date-btn' + (open ? '' : ' off') + (state.date === s ? ' on' : '');
      b.disabled = !open;
      b.setAttribute('data-date', s);
      b.setAttribute('aria-pressed', state.date === s ? 'true' : 'false');
      var dw = document.createElement('span'); dw.className = 'dw'; dw.textContent = DAYS[d.getDay()];
      var dn = document.createElement('span'); dn.className = 'dn'; dn.textContent = d.getDate();
      var dm = document.createElement('span'); dm.className = 'dm';
      dm.textContent = !open ? 'Closed' : (i === 0 ? 'Today' : MONTHS[d.getMonth()]);
      b.appendChild(dw); b.appendChild(dn); b.appendChild(dm);
      dateGrid.appendChild(b);
    }
  }

  function renderTimes() {
    timeGrid.innerHTML = '';
    data.slots.forEach(function (t) {
      var st = state.date ? slotStatus(state.date, t) : 'free';
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'time-btn' + (st !== 'free' ? ' off' : '') + (state.time === t ? ' on' : '');
      b.disabled = st !== 'free';
      b.setAttribute('data-time', t);
      b.setAttribute('aria-pressed', state.time === t ? 'true' : 'false');
      b.textContent = t.replace(/^0/, '');
      timeGrid.appendChild(b);
    });
  }

  function pickDate(s) {
    state.date = s;
    dateVal.value = s;
    if (state.time && slotStatus(s, state.time) !== 'free') {
      state.time = '';
      timeVal.value = '';
    }
    setErr('date', '');
    renderDates();
    renderTimes();
  }

  function clearSchedule() {
    state.date = '';
    state.time = '';
    dateVal.value = '';
    timeVal.value = '';
    altDate.value = '';
    setErr('altdate', '');
  }

  function renderReview() {
    var key = branchKey();
    var f = form.elements;
    var d = parseISO(state.date);
    var patient;
    if (member) {
      patient = [member.name, member.phone + ' · ' + member.email];
    } else {
      patient = [
        f.first_name.value.trim() + ' ' + f.last_name.value.trim(),
        f.phone.value.trim() + ' · ' + f.email.value.trim(),
        'Current patient: ' + (form.querySelector('input[name="current_patient"]:checked').value === 'yes' ? 'Yes' : 'No')
      ];
    }
    var note = f.comments && f.comments.value.trim();
    if (note) patient.push('Comments: ' + note);
    var rows = [
      ['Branch', [data.branches[key].name], 1],
      ['Service', [f.service.value], 1],
      ['Preferred schedule', [d.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) + ' · ' + state.time.replace(/^0/, '')], 2],
      ['Patient', patient, member ? 0 : 3]
    ];
    var box = document.getElementById('review');
    box.innerHTML = '';
    rows.forEach(function (r) {
      var item = document.createElement('div');
      item.className = 'review-item';
      var left = document.createElement('div');
      var label = document.createElement('div');
      label.className = 'review-label';
      label.textContent = r[0];
      left.appendChild(label);
      r[1].forEach(function (line, i) {
        var p = document.createElement('div');
        p.className = i === 0 ? 'review-main' : 'review-sub';
        p.textContent = line;
        left.appendChild(p);
      });
      item.appendChild(left);
      if (r[2]) {
        var edit = document.createElement('button');
        edit.type = 'button';
        edit.className = 'edit-btn';
        edit.setAttribute('data-goto', String(r[2]));
        edit.textContent = 'Edit';
        item.appendChild(edit);
      }
      box.appendChild(item);
    });
  }

  function next() {
    if (!validate(step)) return;
    if (step < last) show(step + 1);
  }

  form.addEventListener('click', function (e) {
    var dBtn = e.target.closest('.date-btn');
    if (dBtn && !dBtn.disabled) {
      altDate.value = '';
      setErr('altdate', '');
      pickDate(dBtn.getAttribute('data-date'));
      return;
    }
    var tBtn = e.target.closest('.time-btn');
    if (tBtn && !tBtn.disabled) {
      state.time = tBtn.getAttribute('data-time');
      timeVal.value = state.time;
      setErr('time', '');
      renderTimes();
      return;
    }
    var ctl = e.target.closest('[data-next], [data-prev], [data-goto]');
    if (!ctl) {
      var tab = e.target.closest('.step-tab');
      if (tab && !tab.disabled) show(Number(tab.parentNode.getAttribute('data-step')));
      return;
    }
    if (ctl.hasAttribute('data-next')) next();
    else if (ctl.hasAttribute('data-prev')) show(step - 1);
    else show(Number(ctl.getAttribute('data-goto')));
  });

  form.addEventListener('change', function (e) {
    if (e.target.name === 'branch') {
      setErr('branch', '');
      if (state.date && !isOpen(branchKey(), parseISO(state.date))) clearSchedule();
    }
    if (e.target.name === 'service') setErr('service', '');
  });

  altDate.min = iso(new Date());
  altDate.addEventListener('change', function () {
    var v = altDate.value;
    if (!v) { setErr('altdate', ''); return; }
    var key = branchKey();
    if (v < iso(new Date())) {
      setErr('altdate', 'Choose today or a later date.');
      altDate.value = '';
      return;
    }
    if (!isOpen(key, parseISO(v))) {
      setErr('altdate', data.branches[key].name + ' is open ' + data.branches[key].daysText + '.');
      altDate.value = '';
      return;
    }
    setErr('altdate', '');
    pickDate(v);
  });

  form.addEventListener('submit', function (e) {
    if (step !== last) {
      e.preventDefault();
      next();
      return;
    }
    if (!validate(1)) { e.preventDefault(); show(1); return; }
    if (!validate(2)) { e.preventDefault(); show(2); return; }
    if (!member && !validate(3)) { e.preventDefault(); show(3); }
  });

  if (data.old) {
    Object.keys(data.old).forEach(function (k) {
      if (form.elements[k]) form.elements[k].value = data.old[k];
    });
    state.date = data.old.date || '';
    state.time = data.old.time || '';
    dateVal.value = state.date;
    timeVal.value = state.time;
    show(last, true);
    if (data.error) {
      formError.textContent = data.error;
      formError.hidden = false;
    }
  } else {
    show(1, true);
  }
})();
