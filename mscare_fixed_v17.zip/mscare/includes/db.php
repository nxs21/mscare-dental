<?php
// PostgreSQL connection (PDO). Edit the values below, or set the environment
// variables MSC_DB_HOST / MSC_DB_PORT / MSC_DB_NAME / MSC_DB_USER / MSC_DB_PASS.
// Set to true while setting up: the real database error is shown on the page.
// Set back to false before going live.
if (!defined('MSC_DEBUG')) define('MSC_DEBUG', true);

function db_fail_text(PDOException $ex, $fallback) {
    return MSC_DEBUG ? $fallback . ' [DB error: ' . $ex->getMessage() . ']' : $fallback;
}

function db() {
    static $pdo = null;
    if ($pdo) return $pdo;

    $host = getenv('MSC_DB_HOST') ?: 'localhost';
    $port = getenv('MSC_DB_PORT') ?: '5432';
    $name = getenv('MSC_DB_NAME') ?: 'mscare';
    $user = getenv('MSC_DB_USER') ?: 'postgres';
    $pass = getenv('MSC_DB_PASS') ?: 'Veron';      // <- change to your password

    $pdo = new PDO("pgsql:host=$host;port=$port;dbname=$name", $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    $pdo->exec("SET TIME ZONE 'Asia/Manila'");
    return $pdo;
}
