<?php
// ============================================================================
// EMAIL defaults. You do NOT need to edit this file.
// The sender mailbox (e.g. a Gmail + App Password) is set from the admin site:
//     Admin > Settings > Email Sender
// Verification codes can be sent to ANY patient email address (Gmail, Yahoo, Outlook, school/work...).
// (Optional) servers can instead set environment variables MSC_SMTP_USER / MSC_SMTP_PASS.
// ============================================================================
return [
    'host'       => getenv('MSC_SMTP_HOST') ?: 'smtp.gmail.com',
    'port'       => (int)(getenv('MSC_SMTP_PORT') ?: 587),     // 587 = STARTTLS, 465 = SSL
    'username'   => getenv('MSC_SMTP_USER') ?: '',
    'password'   => getenv('MSC_SMTP_PASS') ?: '',
    'from_email' => getenv('MSC_SMTP_FROM') ?: '',             // blank = same as username
    'from_name'  => 'MSCare Dental Clinic',
    // XAMPP on Windows often has no CA certificates; keep false there. Set true on a real server.
    'verify_ssl' => false,
    'code_minutes'    => 10,   // how long a code is valid
    'resend_cooldown' => 60,   // seconds before "Resend" is allowed
];
