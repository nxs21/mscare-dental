<?php
// MSCare - patient login & session helpers (shared by every page of the site).
// The session is the single source of truth for the signed-in patient. There is
// deliberately NO "default demo patient" fallback: a page that needs a login
// redirects to login.php instead of showing somebody else's name.
require_once __DIR__ . '/../config.php';

if (session_status() === PHP_SESSION_NONE) {
    $session_dir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'sessions';
    if (!is_dir($session_dir)) { @mkdir($session_dir, 0775, true); }
    if (is_dir($session_dir) && is_writable($session_dir)) { session_save_path($session_dir); }
    // Separate cookie name so a patient login and an admin login can coexist in one browser.
    session_name('MSCAREPATIENT');
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

require_once __DIR__ . '/db.php';

function patient_full_name(array $p) {
    $parts = array_filter([
        trim((string)($p['first_name'] ?? '')),
        trim((string)($p['middle_name'] ?? '')),
        trim((string)($p['last_name'] ?? '')),
    ], static fn($v) => $v !== '');
    return preg_replace('/\s+/', ' ', implode(' ', $parts));
}

function patient_initials(array $p) {
    $f = trim((string)($p['first_name'] ?? ''));
    $l = trim((string)($p['last_name'] ?? ''));
    return strtoupper(mb_substr($f, 0, 1) . mb_substr($l, 0, 1));
}

function login_patient_session(array $p) {
    $_SESSION['mscare_patient'] = [
        'id'          => (int)$p['id'],
        'first_name'  => (string)$p['first_name'],
        'last_name'   => (string)$p['last_name'],
        'middle_name' => (string)($p['middle_name'] ?? ''),
        'full_name'   => patient_full_name($p),
        'email'       => (string)$p['email'],
        'phone'       => (string)$p['phone'],
        'age'         => (int)$p['age'],
        'gender'      => (string)$p['gender'],
        'initials'    => patient_initials($p),
        'is_demo'     => !empty($p['is_demo']),
    ];
}

function current_patient() {
    return (isset($_SESSION['mscare_patient']) && is_array($_SESSION['mscare_patient']))
        ? $_SESSION['mscare_patient'] : null;
}

function patient_id() {
    $p = current_patient();
    return $p ? (int)$p['id'] : 0;
}

function require_patient() {
    if (!current_patient()) {
        $next = basename($_SERVER['SCRIPT_NAME'] ?? 'patient-dashboard.php');
        header('Location: login.php?next=' . rawurlencode($next));
        exit;
    }
}

// ---- Admin session helpers ----
function login_admin_session(array $a) {
    $_SESSION['mscare_admin'] = [
        'id'          => (int)$a['id'],
        'username'    => (string)$a['username'],
        'display_name'=> (string)$a['display_name'],
        'initials'    => (string)$a['initials'],
        'role'        => (string)$a['role'],
        'branch_id'   => isset($a['branch_id']) ? (int)$a['branch_id'] : null,
    ];
}
function current_admin() {
    return (isset($_SESSION['mscare_admin']) && is_array($_SESSION['mscare_admin']))
        ? $_SESSION['mscare_admin'] : null;
}
function admin_id() {
    $a = current_admin();
    return $a ? (int)$a['id'] : 0;
}
function require_admin() {
    if (!current_admin()) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Admin session required.']);
        exit;
    }
}
function refresh_admin_session($id = null) {
    $id = $id ?: admin_id();
    if (!$id) return null;
    $stmt = db()->prepare("SELECT * FROM admins WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    if ($row) { login_admin_session($row); return current_admin(); }
    return null;
}

function refresh_patient_session($id = null) {
    $id = $id ?: patient_id();
    if (!$id) return null;
    $stmt = db()->prepare("SELECT * FROM patients WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    if ($row) { login_patient_session($row); return current_patient(); }
    return null;
}

function flash($message, $type = 'success') {
    $_SESSION['mscare_flash'] = ['message' => $message, 'type' => $type];
}

function take_flash() {
    if (empty($_SESSION['mscare_flash'])) return null;
    $f = $_SESSION['mscare_flash'];
    unset($_SESSION['mscare_flash']);
    return $f;
}

function redirect_to($url) {
    header('Location: ' . $url);
    exit;
}

/** Booking unlocks once the medical history is done and the clinic approved the signature. */
function booking_status($pid) {
    $out = ['med_done' => false, 'consent' => 'none', 'can_book' => false];
    $m = db()->prepare("SELECT is_completed FROM patient_medical_histories WHERE patient_id = :p");
    $m->execute([':p' => $pid]);
    $out['med_done'] = (bool)$m->fetchColumn();
    $c = db()->prepare("SELECT status FROM patient_consents WHERE patient_id = :p");
    $c->execute([':p' => $pid]);
    $out['consent'] = $c->fetchColumn() ?: 'none';
    $out['can_book'] = $out['med_done'] && $out['consent'] === 'approved';
    return $out;
}

/** Postgres open_days text[] -> PHP array */
function pg_days($v) {
    if (is_array($v)) return $v;
    $v = trim((string)$v, '{}');
    return $v === '' ? [] : array_map('trim', explode(',', $v));
}
