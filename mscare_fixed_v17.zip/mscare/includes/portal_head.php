<?php
// Opens a patient-portal page: site header + hero + tab bar.
// Expects (set before including):  $ptitle, $psub, $pactive  (and $patient from require_patient()).
require_once __DIR__ . '/auth.php';
require_patient();
$patient = current_patient();
$page  = 'portal';
$title = $ptitle ?? 'My Portal';
$ptabs = [
    'dashboard'    => ['patient-dashboard.php',    'Dashboard',         $ui['grid']],
    'book'         => ['patient-book.php',         'Book Appointment',  $ui['calendar']],
    'appointments' => ['patient-appointments.php', 'My Appointments',   $ui['history']],
    'history'      => ['patient-history.php',      'Treatment History', $services[0][2]],
    'record'       => ['patient-record.php',       'My Dental Record',  $ui['file']],
    'profile'      => ['patient-profile.php',      'My Profile',        $ui['user']],
];
include __DIR__ . '/header.php';
?>
<section class="portal-hero">
  <div class="container">
    <div class="eyebrow"><?= e($eyebrow ?? 'Patient portal') ?></div>
    <h1><?= e($ptitle ?? 'My Portal') ?></h1>
    <?php if (!empty($psub)): ?><p class="lead"><?= e($psub) ?></p><?php endif; ?>
    <nav class="portal-tabs" aria-label="Patient portal">
      <?php foreach ($ptabs as $key => [$href, $label, $path]): ?>
        <a href="<?= $href ?>"<?= ($pactive ?? '') === $key ? ' class="on" aria-current="page"' : '' ?>><?= icon($path, 18) ?><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
  </div>
</section>
<section class="portal-body">
  <div class="container">
<?php
$flash = take_flash();
if ($flash): ?>
    <div class="banner <?= $flash['type'] === 'error' ? 'err' : 'ok' ?>" role="status">
      <?= icon($flash['type'] === 'error' ? $ui['lock'] : $ui['check'], 20) ?>
      <div class="b-text"><strong><?= e($flash['message']) ?></strong></div>
    </div>
<?php endif; ?>
