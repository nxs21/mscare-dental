<?php
// Live countdown for verification pages. Expects #codeTimer (data-left = seconds until expiry)
// and #resendBtn (data-wait = seconds until Resend is allowed) on the page.
?>
<script>
(function(){
  var t=document.getElementById('codeTimer'), b=document.getElementById('resendBtn');
  if(!t||!b) return;
  var left=parseInt(t.getAttribute('data-left'),10)||0, wait=parseInt(b.getAttribute('data-wait'),10)||0;
  function mmss(n){return Math.floor(n/60)+':'+('0'+(n%60)).slice(-2);}
  function tick(){
    t.textContent = left>0 ? 'Code expires in '+mmss(left) : 'Code expired. Press "Resend code" to get a new one.';
    t.style.color = left>0 ? '' : '#b3261e';
    b.disabled = wait>0;
    b.style.opacity = wait>0 ? .5 : 1; b.style.cursor = wait>0 ? 'not-allowed' : 'pointer';
    b.textContent = wait>0 ? 'Resend code in '+wait+'s' : 'Resend code';
    if(left>0) left--; if(wait>0) wait--;
  }
  tick(); setInterval(tick,1000);
})();
</script>
