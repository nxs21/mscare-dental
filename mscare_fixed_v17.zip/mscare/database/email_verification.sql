-- MSCare: email verification + forgot password
-- Run once in pgAdmin (Query Tool on the "mscare" database) or:
--   psql -U postgres -d mscare -f database/email_verification.sql
-- (Safe to run more than once. The website also applies this automatically.)

-- 1. Patients: has the email been verified?
ALTER TABLE patients ADD COLUMN IF NOT EXISTS email_verified    BOOLEAN     NOT NULL DEFAULT FALSE;
ALTER TABLE patients ADD COLUMN IF NOT EXISTS email_verified_at TIMESTAMPTZ;

-- Everyone who registered BEFORE this feature is treated as verified so they can still log in.
UPDATE patients SET email_verified = TRUE, email_verified_at = COALESCE(email_verified_at, now())
WHERE email_verified = FALSE AND created_at < now();

-- 2. Verification codes: count wrong guesses
ALTER TABLE patient_otps ADD COLUMN IF NOT EXISTS attempts SMALLINT NOT NULL DEFAULT 0;
CREATE INDEX IF NOT EXISTS ix_otps_user_purpose ON patient_otps (user_type, user_id, purpose, created_at DESC);

-- 3. Useful queries
-- Latest codes sent:
--   SELECT id, user_id, purpose, otp_code, expires_at, is_used, attempts, created_at
--   FROM patient_otps WHERE user_type = 'patient' ORDER BY id DESC LIMIT 20;
-- Manually verify a patient:
--   UPDATE patients SET email_verified = TRUE, email_verified_at = now() WHERE email = 'you@email.com';
-- Remove expired codes:
--   DELETE FROM patient_otps WHERE user_type = 'patient' AND (expires_at < now() OR is_used);
