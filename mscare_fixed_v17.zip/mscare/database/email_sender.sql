-- OPTIONAL: set the email SENDER directly from pgAdmin (same as Admin > Settings > Email Sender).
-- Run while connected to the "mscare" database. Replace the email and the 16-letter Gmail App Password.
CREATE TABLE IF NOT EXISTS clinic_settings (
    branch_id smallint NOT NULL,
    setting_key varchar(60) NOT NULL,
    setting_value text NOT NULL DEFAULT '',
    updated_at timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (branch_id, setting_key)
);
INSERT INTO clinic_settings (branch_id, setting_key, setting_value) VALUES
  (0, 'smtp_username',  'yourclinic@gmail.com'),     -- <- sender Gmail
  (0, 'smtp_password',  'abcdefghijklmnop'),         -- <- Gmail App Password (no spaces)
  (0, 'smtp_host',      'smtp.gmail.com'),
  (0, 'smtp_port',      '587'),
  (0, 'smtp_from_name', 'MSCare Dental Clinic')
ON CONFLICT (branch_id, setting_key) DO UPDATE SET setting_value = EXCLUDED.setting_value, updated_at = now();
