-- =============================================================================
-- MSCare Dental Clinic - PostgreSQL seed data (safe to run more than once)
-- This seeds the clinic reference data (branches, services, dentists, admins)
-- and one demo patient. Existing patient accounts are NEVER overwritten.
-- =============================================================================

-- 1. Branches ---------------------------------------------------------------
INSERT INTO branches (code, name, city, address, open_days, phone) VALUES
    ('c1', 'Clinic 1 — Makati', 'Makati',
     '#7 Moonlite Street, Barangay Singkamas, Makati City',
     ARRAY['Mon','Wed','Fri','Sat'], '0917 220 3391'),
    ('c2', 'Clinic 2 — Manila', 'Manila',
     'Burke House No 5 Building, Pedro Gil Street, Sta. Ana, Manila',
     ARRAY['Tue','Thu'], '0917 220 3392')
ON CONFLICT (code) DO UPDATE SET
    name      = EXCLUDED.name,
    city      = EXCLUDED.city,
    address   = EXCLUDED.address,
    open_days = EXCLUDED.open_days,
    phone     = EXCLUDED.phone;

-- 2. Services --------------------------------------------------------------
INSERT INTO services (name, category, sort_order, price, is_active) VALUES
    ('General Dentistry',    'Basic Dental Services', 1,  1000.00, TRUE),
    ('Cleaning',             'Basic Dental Services', 2,  1200.00, TRUE),
    ('Orthodontics',         'Specialized Services',  3, 35000.00, TRUE),
    ('Esthetic Dentistry',   'Specialized Services',  4,  5000.00, TRUE),
    ('Prosthodontics',       'Specialized Services',  5, 12000.00, TRUE),
    ('Root Canal Treatment', 'Specialized Services',  6,  8500.00, TRUE),
    ('Oral Surgery',         'Basic Dental Services', 7,  3000.00, TRUE),
    ('Braces',               'Specialized Services',  8, 45000.00, TRUE)
ON CONFLICT (name) DO UPDATE SET
    category   = EXCLUDED.category,
    sort_order = EXCLUDED.sort_order,
    price      = EXCLUDED.price,
    is_active  = EXCLUDED.is_active;

-- 3. Dentist ---------------------------------------------------------------
INSERT INTO dentists (name, title, license_no, phone, email, is_active) VALUES
    ('Dr. Marilou S. Cariño', 'Chief Dental Officer / Orthodontist',
     'DNT-PH-048291', '0917 220 3391', 'dr.carino@mscare.com', TRUE)
ON CONFLICT (name) DO NOTHING;

-- 4. Admin accounts (admin1 / admin123 and admin2 / admin123) ---------------
INSERT INTO admins (username, password_hash, branch_id, display_name, initials, role, is_active)
VALUES
    ('admin1', '$2y$10$0B1ak7UokGlPWiEdsP7QKuZcsRazRFcair0e2n3AOWzQFL0aLWP92',
     (SELECT id FROM branches WHERE code = 'c1'), 'Clinic 1 Admin', 'A1', 'admin', TRUE),
    ('admin2', '$2y$10$0B1ak7UokGlPWiEdsP7QKuZcsRazRFcair0e2n3AOWzQFL0aLWP92',
     (SELECT id FROM branches WHERE code = 'c2'), 'Clinic 2 Admin', 'A2', 'admin', TRUE)
ON CONFLICT (username) DO UPDATE SET
    password_hash = EXCLUDED.password_hash,
    branch_id     = EXCLUDED.branch_id,
    display_name  = EXCLUDED.display_name,
    initials      = EXCLUDED.initials,
    role          = EXCLUDED.role,
    is_active     = EXCLUDED.is_active;

-- 6. Verification output ----------------------------------------------------
SELECT 'branches' AS item, count(*)::text AS total FROM branches
UNION ALL SELECT 'services', count(*)::text FROM services
UNION ALL SELECT 'dentists', count(*)::text FROM dentists
UNION ALL SELECT 'admins', count(*)::text FROM admins
UNION ALL SELECT 'patients', count(*)::text FROM patients;
