MSCare PostgreSQL Database
===========================

Connection settings (includes/db.php)
  host     localhost
  port     5432
  database mscare
  user     postgres
  password Veron

Fresh install
  1. Open a terminal in C:\xampp\htdocs\mscare\database
  2. createdb -U postgres mscare
  3. psql -U postgres -d mscare -f mscare_full.sql

Existing database (keeps all current patient accounts)
  psql -U postgres -d mscare -f seed.sql

What is included
  mscare_full.sql  Complete 14-table schema, indexes, triggers, views and seed data
  seed.sql         Safe clinic data (2 branches, 8 services, dentist, 2 admins, demo patient)

Demo accounts
