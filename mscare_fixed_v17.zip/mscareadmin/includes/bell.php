<?php
// MSCare Admin - notification bell shown in every page's top bar.
// Shows what needs the clinic's attention for the signed-in admin's branch:
//   * booking requests still waiting for approval (status = Pending)
//   * appointments a patient cancelled from the portal in the last 3 days
// The badge number is the count of those items, so it goes down as requests are handled.

function admin_bell_ensure_table($pdo) {
    if (!empty($_SESSION['bell_tbl_ok'])) return;
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_notif_reads (
        admin_id integer NOT NULL,
        notif_key varchar(24) NOT NULL,
        read_at timestamptz NOT NULL DEFAULT now(),
        PRIMARY KEY (admin_id, notif_key))");
    $_SESSION['bell_tbl_ok'] = 1;
}

function admin_bell_data($branch_id) {
    $out = ['pending' => [], 'cancelled' => [], 'count' => 0];
    try {
        $pdo = db();
        admin_bell_ensure_table($pdo);
        $aid = admin_id();

        // Pending requests (latest 6 shown) + how many are still unread
        $st = $pdo->prepare("SELECT a.id, a.first_name, a.last_name, a.appointment_date, a.appointment_time, s.name AS service_name,
                                    (r.notif_key IS NOT NULL) AS is_read
                               FROM appointments a
                               JOIN services s ON s.id = a.service_id
                               LEFT JOIN admin_notif_reads r ON r.admin_id = :a AND r.notif_key = 'p' || a.id
                              WHERE a.branch_id = :b AND a.status = 'Pending'
                              ORDER BY a.created_at DESC LIMIT 6");
        $st->execute([':a' => $aid, ':b' => $branch_id]);
        $out['pending'] = $st->fetchAll();

        $st = $pdo->prepare("SELECT a.id, a.first_name, a.last_name, a.appointment_date, a.appointment_time, s.name AS service_name,
                                    (r.notif_key IS NOT NULL) AS is_read
                               FROM appointments a
                               JOIN services s ON s.id = a.service_id
                               LEFT JOIN admin_notif_reads r ON r.admin_id = :a AND r.notif_key = 'c' || a.id
                              WHERE a.branch_id = :b AND a.status = 'Cancelled'
                                AND a.admin_notes LIKE 'Cancelled by patient%'
                                AND a.updated_at > now() - interval '3 days'
                              ORDER BY a.updated_at DESC LIMIT 6");
        $st->execute([':a' => $aid, ':b' => $branch_id]);
        $out['cancelled'] = $st->fetchAll();

        // Unread total (not limited to the 6 shown)
        $st = $pdo->prepare("SELECT
              (SELECT COUNT(*) FROM appointments a
                WHERE a.branch_id = :b1 AND a.status = 'Pending'
                  AND NOT EXISTS (SELECT 1 FROM admin_notif_reads r WHERE r.admin_id = :a1 AND r.notif_key = 'p' || a.id))
            + (SELECT COUNT(*) FROM appointments a
                WHERE a.branch_id = :b2 AND a.status = 'Cancelled' AND a.admin_notes LIKE 'Cancelled by patient%'
                  AND a.updated_at > now() - interval '3 days'
                  AND NOT EXISTS (SELECT 1 FROM admin_notif_reads r WHERE r.admin_id = :a2 AND r.notif_key = 'c' || a.id))");
        $st->execute([':a1' => $aid, ':b1' => $branch_id, ':a2' => $aid, ':b2' => $branch_id]);
        $out['count'] = (int)$st->fetchColumn();
    } catch (Throwable $ex) {
        error_log('MSCare admin bell: ' . $ex->getMessage());
    }
    return $out;
}

function admin_bell_item($a, $kind) {
    $name  = trim($a['first_name'] . ' ' . $a['last_name']);
    $when  = date('M j', strtotime($a['appointment_date'])) . ' · ' . date('g:i A', strtotime($a['appointment_time']));
    $title = $kind === 'pending' ? 'New booking request' : 'Cancelled by patient';
    $key   = ($kind === 'pending' ? 'p' : 'c') . (int)$a['id'];
    $read  = !empty($a['is_read']) && $a['is_read'] !== 'f';
    $icon  = $kind === 'pending'
        ? '<path d="M8 3v3M16 3v3M4 8h16M5 5h14a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z"/>'
        : '<path d="M18 6 6 18M6 6l12 12"/>';
    return '<a class="notif-item' . ($read ? '' : ' unread') . '" href="appointments.php" data-key="' . $key . '">'
         . '<span class="notif-icon"' . ($kind === 'pending' ? '' : ' style="background:var(--coral-tint);color:var(--coral);"') . '>'
         . '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' . $icon . '</svg></span>'
         . '<span><div class="notif-title">' . e($title) . ' &mdash; ' . e($name) . '</div>'
         . '<div class="notif-sub">' . e($a['service_name']) . ' · ' . e($when) . '</div></span></a>';
}

/** Returns the bell button + dropdown panel (+ its tiny script, once per page). */
function admin_bell_html() {
    static $printed = false;
    $d = admin_bell_data(admin_clinic_id());
    $n = $d['count'];
    $has = $d['pending'] || $d['cancelled'];
    $h  = '<div class="notif-wrap">';
    $h .= '<button type="button" class="icon-btn" id="bellBtn" style="width:36px;height:36px;cursor:pointer;" aria-label="Notifications' . ($n ? ' (' . $n . ' unread)' : '') . '" aria-haspopup="true" aria-expanded="false">'
        . '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>'
        . '<span class="notif-dot" id="bellDot"' . ($n ? '' : ' hidden') . '>' . ($n > 9 ? '9+' : $n) . '</span>'
        . '</button>';
    $h .= '<div class="notif-panel" id="notifPanel" role="region" aria-label="Notifications">';
    $h .= '<div class="notif-head"><span id="bellHeadText">Notifications' . ($n ? ' (' . $n . ')' : '') . '</span>'
        . '<button type="button" id="bellMarkAll" class="notif-markall"' . ($n ? '' : ' hidden') . '>Mark all as read</button></div>';
    if (!$has) {
        $h .= '<div class="notif-empty">You\'re all caught up. New booking requests and patient cancellations will show up here.</div>';
    } else {
        foreach ($d['pending'] as $a)   $h .= admin_bell_item($a, 'pending');
        foreach ($d['cancelled'] as $a) $h .= admin_bell_item($a, 'cancelled');
    }
    $h .= '<a class="notif-item notif-all" href="appointments.php">View all appointments</a>';
    $h .= '</div></div>';
    if (!$printed) {
        $printed = true;
        $h .= <<<'JS'
<script>
(function () {
  var b = document.getElementById('bellBtn'), p = document.getElementById('notifPanel');
  if (!b || !p || window.__bellInit) return;
  window.__bellInit = 1;
  var dot = document.getElementById('bellDot'), head = document.getElementById('bellHeadText'), all = document.getElementById('bellMarkAll');
  function set(o) { p.classList.toggle('open', o); b.setAttribute('aria-expanded', o ? 'true' : 'false'); }
  function post(body) {
    return fetch('api.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), keepalive: true })
      .then(function (r) { return r.json(); });
  }
  function refresh() {
    var n = p.querySelectorAll('.notif-item.unread').length;
    dot.hidden = n === 0; dot.textContent = n > 9 ? '9+' : n;
    head.textContent = 'Notifications' + (n ? ' (' + n + ')' : '');
    all.hidden = n === 0;
    b.setAttribute('aria-label', 'Notifications' + (n ? ' (' + n + ' unread)' : ''));
  }
  b.addEventListener('click', function (e) { e.stopPropagation(); set(!p.classList.contains('open')); });
  p.addEventListener('click', function (e) { e.stopPropagation(); });
  document.addEventListener('click', function () { set(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') set(false); });
  p.querySelectorAll('.notif-item[data-key]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      e.preventDefault();
      var go = function () { location.href = a.getAttribute('href'); };
      if (!a.classList.contains('unread')) return go();
      a.classList.remove('unread'); refresh();
      post({ action: 'mark_notif_read', key: a.dataset.key }).then(go, go);
    });
  });
  all.addEventListener('click', function () {
    post({ action: 'mark_notif_read', all: true }).then(function (d) {
      if (d.ok) { p.querySelectorAll('.notif-item.unread').forEach(function (i) { i.classList.remove('unread'); }); refresh(); }
    });
  });
})();
</script>
JS;
    }
    return $h;
}
