<?php
// MSCare Admin - PostgreSQL Database Connection
if (!defined('MSC_DEBUG')) define('MSC_DEBUG', true);

function db_fail_text(PDOException $ex, $fallback) {
    return MSC_DEBUG ? $fallback . ' [DB error: ' . $ex->getMessage() . ']' : $fallback;
}

function db() {
    static $pdo = null;
    if ($pdo) return $pdo;

    $host = getenv('MSC_DB_HOST') ?: 'localhost';
    $port = getenv('MSC_DB_PORT') ?: '5432';
    $name = getenv('MSC_DB_NAME') ?: 'mscare';
    $user = getenv('MSC_DB_USER') ?: 'postgres';
    $pass = getenv('MSC_DB_PASS') ?: 'Veron';

    $pdo = new PDO("pgsql:host=$host;port=$port;dbname=$name", $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    $pdo->exec("SET TIME ZONE 'Asia/Manila'");
    return $pdo;
}
